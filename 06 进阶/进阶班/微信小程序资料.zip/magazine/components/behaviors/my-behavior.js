let myBeh = Behavior({
    properties: {
        mainTitle: String,
        subHead: String,
        imgSrc: String
    }
})

export {myBeh}