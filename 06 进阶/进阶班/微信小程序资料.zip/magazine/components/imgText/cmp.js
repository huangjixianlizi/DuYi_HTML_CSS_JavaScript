// 图文组件
import {myBeh} from "../behaviors/my-behavior.js"

Component({
  
  behaviors: [myBeh],
  
  properties: {
    // mainTitle: String,
    // subHead: String,
    // imgSrc: String
  },

  
  data: {

  },

  
  methods: {

  }
})
