import React from 'react';
import { render } from 'react-dom';
import TodoWrapper from './components/TodoWrapper';

render(<TodoWrapper></TodoWrapper>, document.getElementById('root'))