import React from 'react';

let {Provider, Consumer} = React.createContext();

export {
  Provider,
  Consumer
}