import React, { Component } from 'react';

import './style.css';

class Article extends Component {

  render () {
    return (
      <div>Article</div>
    )
  }

}

export default Article;