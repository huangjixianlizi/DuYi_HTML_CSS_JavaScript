export const CHANGE_INPUT_VAL = 'CHANGE_INPUT_VAL';
export const ADD_TODO_ITEM = 'ADD_TODO_ITEM';
export const DELETE_TODO_ITEM = 'DELETE_TODO_ITEM';

export const COUNT_ADD = 'COUNT_ADD';