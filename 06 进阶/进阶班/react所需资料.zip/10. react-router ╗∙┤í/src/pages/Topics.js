import React, { Component } from 'react';

class Topics extends Component {

  render () {
    return (
      <div>话题</div>
    )
  }

}

export default Topics;