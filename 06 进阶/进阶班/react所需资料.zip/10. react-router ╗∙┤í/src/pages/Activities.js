import React, { Component } from 'react';

class Activities extends Component {

  render () {
    return (
      <div>动态</div>
    )
  }

}

export default Activities;