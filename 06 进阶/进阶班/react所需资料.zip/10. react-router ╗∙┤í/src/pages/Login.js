import React, { Component } from 'react';

class Login extends Component {

  render () {
    return (
      <div>登录</div>
    )
  }

}

export default Login;