import React, { Component } from 'react';
import ActivitiesNav from '../../components/activitiesNav/ActivitiesNav';

class Activities extends Component {

  render () {
    return (
      <div>
        <ActivitiesNav></ActivitiesNav>
      </div>
    )
  }

}

export default Activities;