import React, { Component } from 'react';

class Recommended extends Component {

  render () {
    return (
      <div>推荐</div>
    )
  }

}

export default Recommended;