import React, { Component } from 'react';

class Pins extends Component {

  render () {
    return (
      <div>沸点</div>
    )
  }

}

export default Pins;