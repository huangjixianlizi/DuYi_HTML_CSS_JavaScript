import React, { Component } from 'react';

class Articles extends Component {

  render () {
    return (
      <div>文章</div>
    )
  }

}

export default Articles;