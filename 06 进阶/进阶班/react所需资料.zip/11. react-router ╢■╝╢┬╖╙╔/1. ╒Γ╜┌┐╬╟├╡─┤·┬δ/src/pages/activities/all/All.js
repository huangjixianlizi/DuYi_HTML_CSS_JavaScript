import React, { Component } from 'react';

class All extends Component {

  render () {
    return (
      <div>综合</div>
    )
  }

}

export default All;