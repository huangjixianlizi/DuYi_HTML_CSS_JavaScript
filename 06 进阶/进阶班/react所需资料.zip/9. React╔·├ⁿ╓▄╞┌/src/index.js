import React from 'react';
import { render } from 'react-dom';
// import TodoWrapper from './components/TodoWrapper';
import LifeCycle from './components/LifeCycle';

render(<LifeCycle></LifeCycle>, document.getElementById('root'))