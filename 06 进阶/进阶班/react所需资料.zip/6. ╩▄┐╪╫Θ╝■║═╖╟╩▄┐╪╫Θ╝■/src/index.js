import React from 'react';
import { render } from 'react-dom';
// import Control from './components/Control';
import UnControl from './components/UnControl';

render(<UnControl></UnControl>, document.getElementById('root'))