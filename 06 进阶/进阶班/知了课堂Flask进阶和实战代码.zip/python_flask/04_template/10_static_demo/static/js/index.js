/**
 * Created by hynev on 2017/10/20.
 */

alert('hello world');