#encoding: utf-8

DEBUG = True