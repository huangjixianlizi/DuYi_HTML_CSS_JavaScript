#coding: utf8

USER_SESSION_ID = 'ssdfsdafsdfasdf'