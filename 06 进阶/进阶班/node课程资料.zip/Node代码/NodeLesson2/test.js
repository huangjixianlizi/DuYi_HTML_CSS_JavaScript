
var a = 123;
var b = "abc";
var x = {};
var y = {};
var z = x;

//开闭原则

//导出的永远是对象module.exports
module.exports.a = a;
module.exports.b = b;
exports
