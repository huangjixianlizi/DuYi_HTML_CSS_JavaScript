$('#swiper').sliderImg({
    image:['./img/1.jpg','./img/2.jpg','./img/3.jpg','./img/1.jpg']
})