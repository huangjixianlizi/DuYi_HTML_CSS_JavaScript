module.exports = {
    mode:'development'
}