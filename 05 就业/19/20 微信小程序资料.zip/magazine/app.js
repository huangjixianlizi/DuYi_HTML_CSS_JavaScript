//app.js
App({
  a: {
    name: 'shan',
    age: 18
  }
})