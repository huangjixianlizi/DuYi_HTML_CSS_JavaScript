// 大图组件
import {myBeh} from "../behaviors/my-behavior.js"

Component({

  behaviors: [myBeh],

  properties: {
    // imgSrc: String,
    // mainTitle: String
  },

  /**
   * 组件的初始数据
   */
  data: {
  
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
