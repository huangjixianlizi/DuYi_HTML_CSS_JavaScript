<template>
<div>
    404，页面找不到了
</div>

</template>

<script>
export default {

}
</script>

<style scoped>

</style>