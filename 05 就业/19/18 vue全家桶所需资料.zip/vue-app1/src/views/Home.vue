<template>
  <div class="home">
    首页
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'home'
}
</script>

<style scoped>
div {
  color: red;
}
</style>
