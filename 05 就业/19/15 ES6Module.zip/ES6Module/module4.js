// let a = 10

// 默认导出
// export default a;

// let b = 20;
// let c = 30;

// export {b as w, c};
// let a = 10;
// module.exports = a;
// setTimeout(() => {
//     a = 20;
// }, 2000);

// let ms = 'duyi';
// let times = 0;

// setInterval(() => {
//     times++;
// }, 1500);

// let sayHello = () => {
//     console.log('hello ' + times + ' ' + ms);
// }

// export {sayHello};

// let a = 10;
// setInterval(() => {
//     a++;
// }, 1500);
// export {a};