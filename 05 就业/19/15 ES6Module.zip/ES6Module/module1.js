//绝对路径 相对路径./
import {a} from './module2.js';



console.log(a);
let b = a + 10;

console.log(b)




