// let x = 10;
// let y = 20;
// let z = 30;
// // export {x};
// // export {y};
// // export {z};
// // 简化写法
// export {x, y, z};

// export let x = 10;
// export let y = 20;
// export let z = 30;

// let x = 10;
// let say = function () {
//     console.log(x);
// };
// class Person {
//     constructor(name, age) {
//         this.name = name;
//         this.age = age;
//     }
//     sayName () {
//         console.log(this.name);
//     }
// };

// export {
//     x, 
//     say, 
//     Person
// };