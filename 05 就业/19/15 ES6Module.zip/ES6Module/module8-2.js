let a = 30;
let b = 40;
export {a, b};