// let a = 10;
// export {a};
// // es6模块机制 导出值 关键词
// export {a as b};
// 简写
// export let a = 10;

export default 10;