let a = 10;
setInterval(() => {
    a++;
}, 1500);
module.exports = a;