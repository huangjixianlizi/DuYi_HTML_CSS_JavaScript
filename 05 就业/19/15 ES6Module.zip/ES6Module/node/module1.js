// let a = require('./module2.js');
// // 缓存
// console.log(a);
// setInterval(() => {
//     console.log(a);
// }, 1000);

// let fs = require('fs');
// let {readFile, readDir, writeFile} = fs;

// let fs = require('fs');

// let readFile = fs.readFile
// let readDir = fs.readDir;
// let writeFile = fs.readFile;

// ES6
