let x = 10;
let y = 20;
export {x, y};