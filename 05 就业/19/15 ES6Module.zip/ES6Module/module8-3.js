let m = 50;
let n = 60;
let h = 70;
export {m, n, h as l};