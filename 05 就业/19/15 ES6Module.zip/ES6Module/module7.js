let a = 10;
let b = 20;
export {a, b};