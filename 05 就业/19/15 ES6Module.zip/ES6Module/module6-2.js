export const a = 20;
