

var root = window.player;
var dataList = [];
var len = 0;
var audio = root.audioManager;
var contolIndex = null;
var timer = null;
// 获取数据
function getData(url) {
    $.ajax({
        type: 'GET',
        url: url,
        success: function (data) {
            // root.render(data[0]);
           // root.pro.renderAllTime(data[0].duration);

            dataList = data;
            len = data.length;
            contolIndex = new root.controlIndex(len);
            // audio.getAudio(data[0].audio);
            bindEvent();
            bindTouch();
            $('body').trigger('play:change', 0);
        },
        error: function () {
            console.log('error');
        }
    })
}
// 绑定点击事件
function bindEvent() {
    $('body').on('play:change', function(e, index) {
        audio.getAudio(dataList[index].audio);
        root.render(dataList[index]);
        root.pro.renderAllTime(dataList[index].duration);
        if (audio.status == 'play') {
            audio.play();
            rotated(0);
        }
        $('.img-box').attr('data-deg', 0);
        $('.img-box').css({
            transform: 'rotateZ(' + 0 + 'deg)',
            transition: 'none'
        })
    })
    $('.prev').on('click', function (e) {
        var i = contolIndex.prev();
        $('body').trigger('play:change', i);
        root.pro.start(0);
        if(audio.status == 'pause'){
            root.pro.stop();

        }
    });
    $('.next').on('click', function(e) {
        var i = contolIndex.next();
        $('body').trigger('play:change', i);
        root.pro.start(0);
        if(audio.status == 'pause'){
            root.pro.stop();
        }
    });
    $('.play').on('click', function (e) {
        if (audio.status == 'pause') {
            audio.play();
            root.pro.start();
            var deg = $('.img-box').attr('data-deg') || 0;
            rotated(deg);
        } else {
            audio.pause();
            root.pro.stop();
            clearInterval(timer);
        }
        $('.play').toggleClass('playing');
    })
}

function bindTouch(){
    var $spot = $('.spot');
    var bottom = $('.pro-bottom').offset();
    var l = bottom.left;
    var w = bottom.width;
    $spot.on('touchstart',function(){
        root.pro.stop();
    }).on('touchmove',function(e){
        var x = e.changedTouches[0].clientX;
        var per = (x - l) / w;
        if( per >= 0 && per <=1){
            root.pro.update(per);
        }
    }).on('touchend',function(e){
        var x = e.changedTouches[0].clientX;
        var per = (x - l) / w;
        if( per >= 0 && per <=1){
                var time = per * dataList[contolIndex.index].duration; 
                root.pro.start(per);
                audio.playTo(time);
                audio.play();
                audio.status = 'play';
                $('.play').addClass('playing');
        }
    });
}

function rotated(deg) {
    // console.log(deg);
    clearInterval(timer);
    deg = parseInt(deg);
    timer = setInterval(function () {
        deg += 2;
        $('.img-box').attr('data-deg', deg);
        $('.img-box').css({
            transform: 'rotateZ(' + deg + 'deg)',
            transition: 'transform 0.2s linear'
        })
    }, 200);
}
getData('../mock/data.json');


// 信息 + 图片渲染到页面上
// ，点击按钮
// 音频的播放与暂停  切歌
//  图片旋转
// 列表切歌 --> 作业
// 进度条运动与拖拽