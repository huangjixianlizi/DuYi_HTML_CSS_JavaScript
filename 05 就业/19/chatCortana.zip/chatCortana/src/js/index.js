bindEvent();
function bindEvent(){
	$('.send').on('click',function(){
		var val = $('.search').val();
		if(val){//点击发送判断是否为空
			getData(val);
			addDom('my',val);
		}
	});
	$('.search').on('keyup',function(e){
		console.log(e.keyCode);
		if((e.keyCode == 13 && this.value) || (e.keyCode == 32 && this.value == '&nbsp' )){//按下回车符并且有值
			$('.send').trigger('click');
		}
	});
}

function getData(val){
	$.ajax({
		type:'GET',
		url:'http://data.duyiedu.com/api/chat',
		data:{text:val},
		success:function(data){
			// console.log(typeof data);
		var list = typeof data == 'string'?JSON.parse(data) : data;
		// console.log(list);
		addDom('r',list.text);
		},
		error:function(){
			console.log('error');
		}
	})
}
function addDom(who,text){
	if(who == 'my'){
		$('<div class="talk mine">\<div class="user"></div>\<div class="text">'+text+'</div>\</div>').appendTo($('.inner'));
		$('.search').val('');//发出去清空
	}else{
		$('<div class="talk rabit">\<div class="user"></div>\<div class="text">'+text+'</div>\</div>').appendTo($('.inner'));
	}
	$('.content').scrollTop($('.content')[0].scrollHeight);
}