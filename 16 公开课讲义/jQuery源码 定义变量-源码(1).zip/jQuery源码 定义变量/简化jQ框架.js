(function(){
    (21,94) 定义了一些变量 函数 jQuery = function(){}
    (96,283) jquery 添加方法和属性
    (285,347) extend:继承方法
    (349,817)  扩展一些工具
    (877,2856)  sizzle:复杂选择器
    (2880,3042) Callbacks:回调对象  管理函数
    (3043,3183) deferred:延迟对象 异步统一管理
    (3184,3295) support:功能检测
    (3308,3652) data:数据缓存
    (3653,3797) queue: 队列管理功能 dequeue 出队
    (3803,4299) Attr() prop() val（） addClass（）
    (4300,5128) on() trigger() 事件操作
    (5140,6057) DOM操作 appendTo() append()
    (6058,6620) CSS操作
    (6621,7854) 提交数据和ajax ajax() load（）
    (7855,8584) 运动anmiate  show()  hide（）
    (8585,8792) offset()  scrollTop() 位置与尺寸
    (8804,8821) 模块化
})()